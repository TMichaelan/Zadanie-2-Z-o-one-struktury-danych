#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <sstream>
#include <algorithm>
#include <ctime>
#include <fstream>

struct Node;
Node* AVL(std::vector<unsigned int> tablica, int a, int b);
Node* BST(std::vector<unsigned int> tablica);
void InOrder(Node* root);
Node* PostOrderDelete(Node* root, bool path=true);
Node* Delete(Node* root, unsigned int value);
Node* GetMax(Node* root, bool path=true);
Node* GetMin(Node* root, bool path=true);
Node* Insert(Node* root, unsigned int value);
void BFSBalance(Node* root);
unsigned int StringToInt(std::string x);
std::string IntToString(int x);
void Menu(Node* root, bool czy);
unsigned int GetNumber(std::string informacja, unsigned int limit);
unsigned int GetNumberFromFile(std::string x, unsigned int limit);
void SetHeight(Node* root);
int GetBF(Node* root);

std::fstream BSTCreate;
std::fstream inOrderBST;
std::fstream lowestHighestBST;
std::fstream balanceBST;
std::fstream AVLCreate;
std::fstream inOrderAVL;
std::fstream lowestHighestAVL;
std::fstream balanceAVL;

int main(int argc, char* argv[])
{
    std::string name = "TworzenieBST";
    BSTCreate.open(name, std::ios::in | std::ios::out);
    name = "InOrderBST";
    inOrderBST.open(name, std::ios::in | std::ios::out);
    name = "MinMaxBST";
    lowestHighestBST.open(name, std::ios::in | std::ios::out);
    name = "BalanceBST";
    balanceBST.open(name, std::ios::in | std::ios::out);
    name = "TworzenieAVL";
    AVLCreate.open(name, std::ios::in | std::ios::out);
    name = "InOrderAVL";
    inOrderAVL.open(name, std::ios::in | std::ios::out);
    name = "MinMaxAVL";
    lowestHighestAVL.open(name, std::ios::in | std::ios::out);
    name = "BalanceAVL";
    balanceAVL.open(name, std::ios::in | std::ios::out);
    for (int i = 1; i < argc; i++)
    {
        std::ifstream text(argv[i]);
        if (!text.good())
        {
            std::cout << "Brak dostepu do pliku.\n";
            continue;
        }
        std::vector<unsigned int> tablicaWejsciowa;
        while (!text.eof())
        {
            std::string temp;
            getline(text,temp);
            tablicaWejsciowa.push_back(GetNumberFromFile(temp, 4294967295));
        }
        Node* mainRoot = NULL;
        sort(tablicaWejsciowa.begin(), tablicaWejsciowa.end());
        std::clock_t timestart = std::clock();
        mainRoot = AVL(tablicaWejsciowa, 0, tablicaWejsciowa.size() - 1);
        std::clock_t timeend = std::clock();
        std::cout << "Czas tworzenia drzewa AVL: " << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "ms.\n";
        AVLCreate << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
        Menu(mainRoot, true);
        timestart = std::clock();
        mainRoot = BST(tablicaWejsciowa);
        timeend = std::clock();
        std::cout << "Czas tworzenia drzewa BST: " << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "ms.\n";
        BSTCreate << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
        Menu(mainRoot, false);
    }
}

void Menu(Node* root, bool czy)
{
    std::cout << "Drzewo zostalo stworzone.\n";
    std::clock_t timestart;
    std::clock_t timeend;
    timestart = std::clock();
    GetMin(root);
    timeend = std::clock();
    std::cout << "\b] Czas trwania: " << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "ms.\n";
    if (czy)
        lowestHighestAVL << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
    else
        lowestHighestBST << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
    std::cout << "InOrder: [";
    timestart = std::clock();
    InOrder(root);
    timeend = std::clock();
    std::cout << "\b] Czas trwania: " << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "ms.\n";
    if (czy)
        inOrderAVL << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
    else
        inOrderBST << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
    timestart = std::clock();
    BFSBalance(root);
    timeend = std::clock();
    std::cout << "Czas trwania: " << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "ms.\n";
    if (czy)
        balanceAVL << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
    else
        balanceBST << 1000.0 * (timeend - timestart) / CLOCKS_PER_SEC << "\n";
    PostOrderDelete(root, false);
}

unsigned int GetNumber(std::string informacja, unsigned int limit)
{
    unsigned int n;
    for (;;)
    {
        std::cout << informacja;
        std::string l;
        getline(std::cin, l);
        n = StringToInt(l);
        if (IntToString(n) != l || n > limit || n < 1)
        {
            std::cout << "Bledne dane.\n";
            continue;
        }
        break;
    }
    return n;
}

unsigned int GetNumberFromFile(std::string l, unsigned int limit)
{
    unsigned int n;
    n = StringToInt(l);
    return n;
}

std::string IntToString(int x)
{
    std::stringstream y;
    y << x;
    std::string z;
    y >> z;
    return z;
}

unsigned int StringToInt(std::string x)
{
    std::stringstream y;
    y << x;
    unsigned int z;
    y >> z;
    return z;
}

struct Node
{
    Node* left;
    Node* right;
    int height;
    int value;
};

int GetBF(Node* root)
{
    if (root->left == NULL && root->right == NULL)
        return 0;
    else if (root->left == NULL && root->right != NULL)
        return 0-root->right->height;
    else if (root->left != NULL && root->right == NULL)
        return root->left->height;
    return root->left->height - root->right->height;
}

void BFSBalance(Node* root)
{
    std::queue<Node*> x;
    x.push(root);
    while (!x.empty())
    {
        Node* t = x.front();
        x.pop();
        while (abs(GetBF(t)) > 1)
        {
            int value = t->value;
            Delete(t, t->value);
            Insert(root, value);
        }
        if (t->left != NULL)
            x.push(t->left);
        if (t->right != NULL)
            x.push(t->right);
    }
}

Node* AVL(std::vector<unsigned int> tablica, int a, int b)
{
    if (b < a)
        return NULL;
    int i = floor((a + b) / 2.0);
    Node* root = (struct Node*)malloc(sizeof(Node));
    root->value = tablica[i];
    root->left = AVL(tablica, a, i - 1);
    root->right = AVL(tablica, i + 1, b);
    SetHeight(root);
    return root;
}

Node* BST(std::vector<unsigned int> tablica)
{
    Node* mainRoot = NULL;
    mainRoot = Insert(mainRoot, tablica[0]);
    for (int i = 1; i < tablica.size(); i++)
    {
        Insert(mainRoot, tablica[i]);
    }
    return mainRoot;
}

void InOrder(Node* root)
{
    if (root->left != NULL)
        InOrder(root->left);
    std::cout << root->value << " ";
    if (root->right != NULL)
        InOrder(root->right);
}

Node* PostOrderDelete(Node* root, bool path)
{
    if (root->left != NULL)
        root->left = PostOrderDelete(root->left, path);
    if (root->right != NULL)
        root->right = PostOrderDelete(root->right, path);
    free(root);
    return NULL;
}

Node* Delete(Node* root, unsigned int value)
{
    if (root == NULL)
    {
        std::cout << "Drzewo nie istnieje.\n";
        return NULL;
    }
    if (root->value != value)
    {
        if (root->value < value)
        {
            if (root->right != NULL)
            {
                root->right = Delete(root->right, value);
            }
            else
            {
                std::cout << "Element " << value << " nie istnieje.\n";
                return NULL;
            }
        }
        else
        {
            if (root->left != NULL)
            {
                root->left = Delete(root->left, value);
            }
            else
            {
                std::cout << "Element " << value << " nie istnieje.\n";
                return NULL;
            }
        }
    }
    else
    {
        if (root->left == NULL && root->right == NULL)
        {
            free(root);
            return NULL;
        }
        else if (root->left != NULL && root->right != NULL)
        {
            if (root->left->height > root->right->height)
            {
                Node* tmp = GetMax(root->left, false);
                root->value = tmp->value;
                root->left = Delete(root->left, tmp->value);
            }
            else
            {
                Node* tmp = GetMin(root->right, false);
                root->value = tmp->value;
                root->right = Delete(root->right, tmp->value);
            }
        }
        else if (root->left != NULL)
        {
            Node* tmp = GetMax(root->left, false);
            root->value = tmp->value;
            root->left = Delete(root->left, tmp->value);
        }
        else
        {
            Node* tmp = GetMin(root->right, false);
            root->value = tmp->value;
            root->right = Delete(root->right, tmp->value);
        }
    }
    SetHeight(root);
    return root;
}

Node* GetMax(Node* root, bool path)
{
    Node* x = root;
    while (x->right != NULL)
    {
        x = x->right;
    }
    return x;
}

Node* GetMin(Node* root, bool path)
{
    Node* x = root;
    while (x->left != NULL)
    {
        x = x->left;
    }
    return x;
}

void SetHeight(Node* root)
{
    if (root->left == NULL && root->right == NULL)
        root->height = 1;
    else if (root->left == NULL && root->right != NULL)
        root->height = root->right->height + 1;
    else if (root->left != NULL && root->right == NULL)
        root->height = root->left->height + 1;
    else
        root->height = (root->left->height > root->right->height ? root->left->height : root->right->height) + 1;
}

Node* Insert(Node* root, unsigned int value)
{
    if (root == NULL)
    {
        Node* x = (struct Node*)malloc(sizeof(Node));
        x->value = value;
        x->left = NULL;
        x->right = NULL;
        x->height = 1;
        return x;
    }
    if (root->value < value)
    {
        if (root->right == NULL)
        {
            Node* x = (struct Node*)malloc(sizeof(Node));
            x->value = value;
            x->left = NULL;
            x->right = NULL;
            x->height = 1;
            root->right = x;
        }
        else
        {
            Insert(root->right, value);
        }
    }
    else
    {
        if (root->left == NULL)
        {
            Node* x = (struct Node*)malloc(sizeof(Node));
            x->value = value;
            x->left = NULL;
            x->right = NULL;
            x->height = 1;
            root->left = x;
        }
        else
        {
            Insert(root->left, value);
        }
    }
    SetHeight(root);
}
